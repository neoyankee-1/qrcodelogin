import { describe, expect, it } from 'vitest';
import { buildLoginPayload, humanizePayload } from '../src/lib/payload';

describe('buildLoginPayload', () => {
  it('builds username tab password enter', () => {
    expect(
      buildLoginPayload({
        username: 'angelo',
        password: 'sparky123',
        includeTab: true,
        includeEnter: true
      })
    ).toBe('angelo\tsparky123\n');
  });

  it('builds username and password without control keys', () => {
    expect(
      buildLoginPayload({
        username: 'angelo',
        password: 'sparky123',
        includeTab: false,
        includeEnter: false
      })
    ).toBe('angelosparky123');
  });

  it('preserves selected control keys even when fields are empty', () => {
    expect(
      buildLoginPayload({
        username: '',
        password: '',
        includeTab: true,
        includeEnter: true
      })
    ).toBe('\t\n');
  });
});

describe('humanizePayload', () => {
  it('displays tabs and line breaks as readable tokens', () => {
    expect(humanizePayload('angelo\tsparky123\n')).toBe('angelo[TAB]sparky123[ENTER]');
  });
});
