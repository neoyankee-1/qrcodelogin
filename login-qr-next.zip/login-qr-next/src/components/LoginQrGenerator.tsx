'use client';

import { useEffect, useMemo, useState } from 'react';
import QRCode from 'qrcode';
import { buildLoginPayload, humanizePayload } from '@/lib/payload';

export default function LoginQrGenerator() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [includeTab, setIncludeTab] = useState(true);
  const [includeEnter, setIncludeEnter] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [copied, setCopied] = useState(false);
  const [qrDataUrl, setQrDataUrl] = useState('');

  const payload = useMemo(
    () => buildLoginPayload({ username, password, includeTab, includeEnter }),
    [username, password, includeTab, includeEnter]
  );

  const hasContent = username.length > 0 || password.length > 0;
  const displayPayload = useMemo(() => humanizePayload(payload), [payload]);

  useEffect(() => {
    let cancelled = false;

    async function generateQr() {
      if (!hasContent) {
        setQrDataUrl('');
        return;
      }

      try {
        const dataUrl = await QRCode.toDataURL(payload, {
          width: 360,
          margin: 2,
          errorCorrectionLevel: 'H'
        });

        if (!cancelled) setQrDataUrl(dataUrl);
      } catch {
        if (!cancelled) setQrDataUrl('');
      }
    }

    generateQr();
    return () => {
      cancelled = true;
    };
  }, [payload, hasContent]);

  async function copyPayload() {
    if (!hasContent) return;

    try {
      await navigator.clipboard.writeText(payload);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1400);
    } catch {
      const textArea = document.createElement('textarea');
      textArea.value = payload;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1400);
    }
  }

  function downloadQr() {
    if (!qrDataUrl) return;

    const link = document.createElement('a');
    link.href = qrDataUrl;
    link.download = 'login-qr-code.png';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  return (
    <main className="page">
      <section className="hero">
        <div className="copy">
          <div className="badge">▦ Login QR Generator</div>
          <h1>Generate keyboard-style login QR codes.</h1>
          <p>
            Create a QR payload that scans like keystrokes: username, optional Tab,
            password, optional Enter.
          </p>
        </div>
      </section>

      <section className="appGrid" aria-label="Login QR generator">
        <form className="panel" onSubmit={(event) => event.preventDefault()}>
          <label>
            Username
            <input
              value={username}
              onChange={(event) => setUsername(event.target.value)}
              placeholder="your.username@example.com"
              autoComplete="username"
            />
          </label>

          <label>
            Password
            <div className="passwordRow">
              <input
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                placeholder="Enter password"
                type={showPassword ? 'text' : 'password'}
                autoComplete="current-password"
              />
              <button type="button" className="ghost" onClick={() => setShowPassword((value) => !value)}>
                {showPassword ? 'Hide' : 'Show'}
              </button>
            </div>
          </label>

          <div className="optionGrid">
            <label className="option">
              <input
                type="checkbox"
                checked={includeTab}
                onChange={(event) => setIncludeTab(event.target.checked)}
              />
              <span>
                <strong>Add Tab after username</strong>
                <small>Moves focus to the password field.</small>
              </span>
            </label>

            <label className="option">
              <input
                type="checkbox"
                checked={includeEnter}
                onChange={(event) => setIncludeEnter(event.target.checked)}
              />
              <span>
                <strong>Add Enter after password</strong>
                <small>Submits the login form.</small>
              </span>
            </label>
          </div>

          <div className="previewBox">
            <strong>Payload preview</strong>
            <code>{hasContent ? displayPayload : 'Your QR payload will appear here'}</code>
          </div>

          <div className="buttonRow">
            <button type="button" onClick={copyPayload} disabled={!hasContent}>
              {copied ? 'Copied' : 'Copy payload'}
            </button>
            <button type="button" className="ghost" onClick={downloadQr} disabled={!qrDataUrl}>
              Download QR PNG
            </button>
          </div>

          <p className="warning">
            This QR contains the password in plain text. Treat the QR image like the password itself.
          </p>
        </form>

        <aside className="qrPanel" aria-live="polite">
          {qrDataUrl ? (
            <>
              <div className="qrBox">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={qrDataUrl} alt="Generated login QR code" width="360" height="360" />
              </div>
              <strong>Ready to scan</strong>
              <p>
                Sequence: username → {includeTab ? 'Tab → ' : ''}password{includeEnter ? ' → Enter' : ''}
              </p>
            </>
          ) : (
            <div className="emptyState">
              <div className="emptyIcon">▦</div>
              <strong>No QR yet</strong>
              <p>Add a username or password to generate one.</p>
            </div>
          )}
        </aside>
      </section>

      <style jsx>{`
        .page {
          min-height: 100vh;
          width: min(1120px, calc(100% - 32px));
          margin: 0 auto;
          padding: 48px 0;
        }

        .hero {
          margin-bottom: 24px;
        }

        .copy {
          max-width: 760px;
        }

        .badge {
          display: inline-flex;
          border: 1px solid rgba(6, 182, 212, 0.35);
          background: rgba(6, 182, 212, 0.1);
          color: #67e8f9;
          border-radius: 999px;
          padding: 7px 12px;
          font-size: 14px;
          font-weight: 700;
          margin-bottom: 14px;
        }

        h1 {
          font-size: clamp(38px, 6vw, 68px);
          line-height: 0.95;
          letter-spacing: -2.5px;
          margin: 0;
        }

        .copy p {
          color: var(--muted);
          font-size: 18px;
          line-height: 1.55;
          margin: 18px 0 0;
        }

        .appGrid {
          display: grid;
          grid-template-columns: minmax(0, 1fr) minmax(320px, 440px);
          gap: 24px;
          align-items: stretch;
        }

        .panel,
        .qrPanel {
          border: 1px solid var(--border);
          background: rgba(23, 23, 23, 0.92);
          backdrop-filter: blur(12px);
          border-radius: 28px;
          padding: 24px;
          box-shadow: 0 24px 80px rgba(0, 0, 0, 0.35);
        }

        label {
          display: block;
          color: #e5e5e5;
          font-weight: 750;
          margin-bottom: 18px;
        }

        input[type='text'],
        input[type='password'],
        input:not([type]) {
          display: block;
          width: 100%;
          margin-top: 8px;
          background: var(--panel-2);
          color: white;
          border: 1px solid #3f3f46;
          border-radius: 16px;
          padding: 13px 14px;
          outline: none;
        }

        input:focus {
          border-color: var(--accent);
          box-shadow: 0 0 0 4px rgba(6, 182, 212, 0.12);
        }

        .passwordRow {
          display: flex;
          gap: 10px;
        }

        .optionGrid {
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 12px;
          margin-bottom: 18px;
        }

        .option {
          display: flex;
          align-items: flex-start;
          gap: 12px;
          margin: 0;
          padding: 15px;
          border: 1px solid var(--border);
          background: var(--panel-2);
          border-radius: 18px;
          cursor: pointer;
        }

        .option input {
          margin-top: 3px;
          accent-color: var(--accent);
          width: 18px;
          height: 18px;
        }

        small {
          display: block;
          color: var(--soft);
          font-weight: 500;
          margin-top: 4px;
        }

        .previewBox {
          border: 1px solid var(--border);
          background: var(--panel-2);
          border-radius: 18px;
          padding: 16px;
          margin-bottom: 18px;
        }

        code {
          display: block;
          color: #a5f3fc;
          overflow-wrap: anywhere;
          margin-top: 8px;
          min-height: 24px;
        }

        .buttonRow {
          display: flex;
          flex-wrap: wrap;
          gap: 12px;
          margin-bottom: 16px;
        }

        button {
          border: 0;
          border-radius: 16px;
          padding: 12px 16px;
          font-weight: 850;
          background: var(--accent);
          color: var(--accent-ink);
          cursor: pointer;
        }

        .ghost {
          border: 1px solid #404040;
          background: #262626;
          color: white;
        }

        .warning {
          color: var(--soft);
          font-size: 13px;
          line-height: 1.55;
          margin: 0;
        }

        .qrPanel {
          background: white;
          color: #111827;
          display: flex;
          min-height: 480px;
          align-items: center;
          justify-content: center;
          text-align: center;
          flex-direction: column;
        }

        .qrBox {
          padding: 16px;
          border: 1px solid #e5e7eb;
          border-radius: 24px;
          margin-bottom: 18px;
        }

        .qrBox img {
          display: block;
          max-width: 100%;
          height: auto;
        }

        .qrPanel p {
          color: #737373;
          font-size: 14px;
          margin: 8px 0 0;
        }

        .emptyIcon {
          width: 96px;
          height: 96px;
          border-radius: 22px;
          background: #f5f5f5;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 42px;
          margin: 0 auto 16px;
        }

        @media (max-width: 860px) {
          .appGrid,
          .optionGrid {
            grid-template-columns: 1fr;
          }

          .page {
            padding: 28px 0;
          }
        }
      `}</style>
    </main>
  );
}
