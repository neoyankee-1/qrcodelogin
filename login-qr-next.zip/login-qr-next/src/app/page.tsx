import LoginQrGenerator from '@/components/LoginQrGenerator';

export default function Home() {
  return <LoginQrGenerator />;
}
