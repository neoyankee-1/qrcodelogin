import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Login QR Generator',
  description: 'Generate a keyboard-style login QR payload with username, Tab, password, and Enter.'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
