export type LoginPayloadInput = {
  username: string;
  password: string;
  includeTab: boolean;
  includeEnter: boolean;
};

export function buildLoginPayload({
  username,
  password,
  includeTab,
  includeEnter
}: LoginPayloadInput): string {
  const tab = includeTab ? '\t' : '';
  const enter = includeEnter ? '\n' : '';
  return `${username}${tab}${password}${enter}`;
}

export function humanizePayload(payload: string): string {
  return payload.replace(/\t/g, '[TAB]').replace(/\n/g, '[ENTER]');
}
